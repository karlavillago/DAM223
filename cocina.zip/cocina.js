const menu = [
    { nombre: 'sopa' },
    { nombre: 'pollo' },
    { nombre: 'chilaquiles' },
    { nombre: 'Hot cakes' },
    { nombre: 'Hamburguesa' },
    { nombre: 'Pure de papa' }
];

function listarMenu() {
    return menu;
}

function obtenerPlatillo(nombre) {
    return menu.find(platillo => platillo.nombre === nombre) || null;
}

function agregarPlatillo(orden, nombre) {
    const platillo = obtenerPlatillo(nombre);

    if (platillo) {
        orden.push({ nombre: platillo.nombre });
        return platillo;
    }

    return null;
}

function editarPlatillo(orden, nombreAnterior, nombreNuevo) {
    const platillo = orden.find(
        item => item.nombre === nombreAnterior
    );

    if (platillo) {
        platillo.nombre = nombreNuevo;
        return platillo;
    }

    return null;
}

function eliminarPlatillo(orden, nombre) {
    const posicion = orden.findIndex(
        item => item.nombre === nombre
    );

    if (posicion !== -1) {
        return orden.splice(posicion, 1)[0];
    }

    return null;
}

function listarOrden(orden) {
    return orden;
}

module.exports = {
    menu,
    listarMenu,
    obtenerPlatillo,
    agregarPlatillo,
    editarPlatillo,
    eliminarPlatillo,
    listarOrden
};